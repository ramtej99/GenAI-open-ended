import { useState, useRef, useEffect } from "react";

const HEALTH_KNOWLEDGE_BASE = [
  {
    id: 1, category: "Symptoms", tags: ["fever", "temperature", "high temperature", "chills"],
    question: "What should I do if I have a fever?",
    answer: "A fever (temperature above 38°C/100.4°F) is your body fighting infection. Rest and stay hydrated. Adults can take paracetamol or ibuprofen as directed. Seek immediate care if fever exceeds 39.4°C (103°F), lasts more than 3 days, or is accompanied by severe headache, stiff neck, rash, or difficulty breathing.",
    keywords: ["fever", "temperature", "hot", "chills", "sweating"]
  },
  {
    id: 2, category: "Symptoms", tags: ["headache", "migraine", "head pain"],
    question: "How do I manage a headache or migraine?",
    answer: "For tension headaches: rest in a quiet, dark room; apply a cold or warm compress; stay hydrated; try OTC pain relievers like ibuprofen or paracetamol. Migraines may need prescription medication. See a doctor if headaches are sudden and severe, occur after head injury, or are accompanied by fever, stiff neck, confusion, or vision changes.",
    keywords: ["headache", "migraine", "head pain", "throbbing", "head hurts"]
  },
  {
    id: 3, category: "Nutrition", tags: ["diet", "eating", "food", "nutrition"],
    question: "What is a balanced diet?",
    answer: "A balanced diet includes: 50% fruits and vegetables, 25% whole grains, 25% lean protein. Limit saturated fats, added sugars, and salt. Aim for 8 glasses of water daily. The WHO recommends at least 400g (5 portions) of fruit and vegetables per day. Limit sugar to less than 10% of daily energy intake and salt to less than 5g per day.",
    keywords: ["diet", "nutrition", "eat", "food", "balanced", "healthy eating", "vegetables", "fruits"]
  },
  {
    id: 4, category: "Exercise", tags: ["exercise", "fitness", "workout", "physical activity"],
    question: "How much exercise do I need?",
    answer: "WHO recommends adults (18–64) get 150–300 minutes of moderate-intensity aerobic activity per week, or 75–150 minutes of vigorous-intensity activity. Include muscle-strengthening activities 2+ days per week. Even short bouts of 10 minutes count. Physical activity reduces risk of heart disease, diabetes, depression, and some cancers.",
    keywords: ["exercise", "workout", "fitness", "physical activity", "gym", "walking", "running"]
  },
  {
    id: 5, category: "Sleep", tags: ["sleep", "insomnia", "rest", "tired"],
    question: "How many hours of sleep do I need?",
    answer: "Adults need 7–9 hours per night (National Sleep Foundation). Teens need 8–10 hours; school-age children 9–11 hours. Poor sleep is linked to obesity, diabetes, cardiovascular disease, and depression. Tips: maintain a consistent sleep schedule, avoid screens 1 hour before bed, keep your bedroom cool and dark, limit caffeine after 2 PM.",
    keywords: ["sleep", "insomnia", "tired", "fatigue", "rest", "awake", "cant sleep", "sleepy"]
  },
  {
    id: 6, category: "Mental Health", tags: ["anxiety", "stress", "mental health", "worry"],
    question: "How can I manage anxiety and stress?",
    answer: "Evidence-based strategies include: deep breathing (4-7-8 technique), regular exercise, mindfulness meditation, limiting caffeine and alcohol, adequate sleep, journaling, and talking to trusted friends. Cognitive Behavioral Therapy (CBT) is highly effective. If anxiety significantly impacts daily life, consult a mental health professional. Crisis support: contact a local helpline.",
    keywords: ["anxiety", "stress", "worry", "panic", "nervous", "mental health", "depression", "sad"]
  },
  {
    id: 7, category: "Chronic Disease", tags: ["diabetes", "blood sugar", "glucose"],
    question: "What are early signs of diabetes?",
    answer: "Common early signs include: frequent urination, excessive thirst, unexplained weight loss, blurry vision, slow-healing wounds, frequent infections, numbness/tingling in hands or feet, fatigue. Type 2 diabetes often develops gradually. Risk factors: obesity, family history, age over 45, physical inactivity, prediabetes. Get a blood glucose test if you notice these symptoms.",
    keywords: ["diabetes", "blood sugar", "glucose", "thirsty", "urination", "insulin"]
  },
  {
    id: 8, category: "Chronic Disease", tags: ["hypertension", "blood pressure", "heart"],
    question: "What is high blood pressure and how do I manage it?",
    answer: "High blood pressure (hypertension) is ≥130/80 mmHg. It's often called the 'silent killer' — no symptoms until serious damage occurs. Management: reduce sodium (<2,300mg/day), exercise regularly, maintain healthy weight, limit alcohol, quit smoking, manage stress. Medications are often needed. Monitor BP regularly at home. Uncontrolled hypertension leads to heart attack, stroke, and kidney disease.",
    keywords: ["blood pressure", "hypertension", "heart", "cardiovascular", "stroke", "systolic", "diastolic"]
  },
  {
    id: 9, category: "First Aid", tags: ["burn", "wound", "cut", "first aid"],
    question: "How do I treat a minor burn or cut?",
    answer: "For minor burns: run cool (not cold) water over burn for 10–20 min, don't use ice or butter, cover with sterile dressing. Seek help for burns larger than 3 inches, on face/hands/feet/genitals, or if blistering is severe. For cuts: apply pressure to stop bleeding, clean with water, apply antiseptic, cover with bandage. Seek care for deep wounds, those that won't stop bleeding, or if caused by a rusty object.",
    keywords: ["burn", "cut", "wound", "bleeding", "first aid", "injury", "bandage"]
  },
  {
    id: 10, category: "Medications", tags: ["medication", "drug", "medicine", "side effects"],
    question: "What should I know about taking medications safely?",
    answer: "Always: take as prescribed, complete full antibiotic courses, never share medications, check expiry dates, inform all doctors about all medications/supplements to avoid interactions, store properly (some need refrigeration). Be aware of common interactions: aspirin + ibuprofen, blood thinners + vitamin K-rich foods, SSRIs + St. John's Wort. Never stop medications abruptly without consulting your doctor.",
    keywords: ["medication", "medicine", "drug", "prescription", "side effects", "antibiotic", "pill"]
  },
  {
    id: 11, category: "Prevention", tags: ["vaccine", "vaccination", "immunization"],
    question: "What vaccinations do adults need?",
    answer: "Key adult vaccines: Annual flu shot (everyone), COVID-19 (updated boosters), Tdap booster every 10 years (tetanus/diphtheria/pertussis), Shingles vaccine (age 50+), Pneumococcal vaccines (age 65+), HPV vaccine (up to age 45), Hepatitis B (if not previously vaccinated). Travel vaccines depend on destination. Consult your doctor or pharmacist for a personalized vaccination schedule.",
    keywords: ["vaccine", "vaccination", "immunization", "flu shot", "covid", "booster", "immunity"]
  },
  {
    id: 12, category: "Prevention", tags: ["cancer screening", "cancer", "mammogram", "colonoscopy"],
    question: "When should I get cancer screenings?",
    answer: "Recommended screenings: Breast cancer — mammogram every 1–2 years from age 40–50. Cervical cancer — Pap smear every 3 years age 21–65. Colorectal cancer — colonoscopy every 10 years from age 45. Lung cancer — annual low-dose CT for heavy smokers age 50–80. Prostate cancer — discuss PSA test with doctor from age 50 (or 40–45 if high risk). Skin — annual dermatologist check if high risk.",
    keywords: ["cancer", "screening", "mammogram", "colonoscopy", "pap smear", "tumor", "biopsy"]
  },
  {
    id: 13, category: "Digestive Health", tags: ["stomach", "digestion", "gut", "bloating", "nausea"],
    question: "How do I manage digestive issues like bloating or nausea?",
    answer: "For bloating: eat slowly, avoid carbonated drinks, reduce FODMAP foods (beans, lactose, onions), try probiotic-rich foods like yogurt. For nausea: eat bland foods (BRAT diet — bananas, rice, applesauce, toast), sip clear fluids slowly, try ginger tea, avoid strong smells. See a doctor if nausea/vomiting persists >2 days, is severe, or accompanied by blood, severe abdominal pain, or signs of dehydration.",
    keywords: ["stomach", "nausea", "vomiting", "bloating", "digestive", "gut", "bowel", "diarrhea", "constipation"]
  },
  {
    id: 14, category: "Hydration", tags: ["water", "hydration", "dehydration", "fluid"],
    question: "How much water should I drink daily?",
    answer: "General recommendation: 8 cups (2 liters) per day for adults, though needs vary. Drink more if: exercising, in hot weather, pregnant or breastfeeding, or recovering from illness. Signs of dehydration: dark urine, dizziness, fatigue, dry mouth. Severe dehydration (no urination, rapid heartbeat, confusion) requires immediate medical attention. Water-rich foods (cucumbers, watermelon) also count toward hydration.",
    keywords: ["water", "hydration", "drink", "dehydration", "thirsty", "fluid", "urine"]
  },
  {
    id: 15, category: "Emergency", tags: ["emergency", "heart attack", "stroke", "911"],
    question: "What are signs of a heart attack or stroke?",
    answer: "HEART ATTACK signs (CALL 911 IMMEDIATELY): chest pressure/squeezing/pain, pain spreading to arm/jaw/neck/back, shortness of breath, cold sweat, nausea, dizziness. STROKE — use FAST: Face drooping, Arm weakness, Speech difficulty, Time to call 911. Every minute matters — brain cells die rapidly without blood flow. Do not drive yourself; call emergency services immediately.",
    keywords: ["heart attack", "stroke", "chest pain", "emergency", "911", "heart", "cardiac"]
  },
  {
    id: 16, category: "Skin Health", tags: ["skin", "rash", "acne", "dermatology"],
    question: "How do I care for my skin and recognize problem signs?",
    answer: "Daily skincare: gentle cleanser, moisturizer, SPF 30+ sunscreen (even on cloudy days). For acne: don't squeeze pimples, use non-comedogenic products, try benzoyl peroxide or salicylic acid. See a dermatologist for: moles changing in size/color/shape (ABCDEs of melanoma), rashes that spread or don't improve in 1–2 weeks, persistent itching, or skin symptoms with fever.",
    keywords: ["skin", "rash", "acne", "pimple", "mole", "sunscreen", "dermatology", "itch", "hives"]
  },
  {
    id: 17, category: "Eye Health", tags: ["eyes", "vision", "eyesight"],
    question: "How do I maintain good eye health?",
    answer: "Get comprehensive eye exams every 1–2 years. Wear UV-protective sunglasses outdoors. Practice 20-20-20 rule for screen fatigue: every 20 minutes, look at something 20 feet away for 20 seconds. Eat foods rich in lutein (leafy greens), omega-3s, and vitamins C and E. Never share contact lenses. Seek urgent care for sudden vision loss, eye pain, flashing lights, or 'floaters' (can indicate retinal detachment).",
    keywords: ["eyes", "vision", "eyesight", "glasses", "contact lens", "blurry", "floaters"]
  },
  {
    id: 18, category: "Respiratory", tags: ["breathing", "asthma", "lungs", "cough"],
    question: "How should I manage a persistent cough or breathing difficulty?",
    answer: "Common causes of persistent cough: post-nasal drip, asthma, GERD, medications (ACE inhibitors), infection. Try: staying hydrated, honey (for adults), humidifier, elevating head during sleep. For asthma: follow your action plan, avoid triggers (pollen, smoke, dust mites), carry rescue inhaler always. Seek immediate care for: sudden severe breathlessness, blue lips/fingertips, coughing blood, or cough with high fever.",
    keywords: ["cough", "breathing", "asthma", "lungs", "wheeze", "shortness of breath", "inhaler"]
  }
];

function cosineSimilarity(str1, str2) {
  const words1 = str1.toLowerCase().split(/\W+/).filter(Boolean);
  const words2 = str2.toLowerCase().split(/\W+/).filter(Boolean);
  const vocab = [...new Set([...words1, ...words2])];
  const vec1 = vocab.map(w => words1.filter(x => x === w).length);
  const vec2 = vocab.map(w => words2.filter(x => x === w).length);
  const dot = vec1.reduce((s, v, i) => s + v * vec2[i], 0);
  const mag1 = Math.sqrt(vec1.reduce((s, v) => s + v * v, 0));
  const mag2 = Math.sqrt(vec2.reduce((s, v) => s + v * v, 0));
  return mag1 && mag2 ? dot / (mag1 * mag2) : 0;
}

function retrieveDocs(query, topK = 3, threshold = 0.05) {
  const q = query.toLowerCase();
  const scored = HEALTH_KNOWLEDGE_BASE.map(doc => {
    const keywordScore = doc.keywords.filter(k => q.includes(k)).length * 0.4;
    const tagScore = doc.tags.filter(t => q.includes(t)).length * 0.3;
    const cosScore = cosineSimilarity(query, doc.question + " " + doc.keywords.join(" ")) * 0.3;
    return { ...doc, score: keywordScore + tagScore + cosScore };
  });
  return scored
    .filter(d => d.score > threshold)
    .sort((a, b) => b.score - a.score)
    .slice(0, topK);
}

const SYSTEM_PROMPT = `You are MedGuide, a knowledgeable and empathetic AI health assistant. You use Retrieval-Augmented Generation (RAG) to provide accurate, evidence-based health information.

IMPORTANT RULES:
1. Always base your responses primarily on the provided context documents
2. Be warm, empathetic, and non-judgmental
3. For serious symptoms, ALWAYS advise consulting a healthcare professional
4. For emergencies (chest pain, stroke signs, severe breathing difficulty), immediately direct to emergency services
5. Never diagnose conditions — provide information and guidance only
6. Cite the category of information you're using
7. If context doesn't cover the question, say so honestly and recommend professional consultation
8. Keep responses clear, structured, and actionable (use bullet points when helpful)
9. Always end serious health concerns with a reminder to consult a doctor

Response format:
- Lead with the most important/urgent information
- Use bullet points for lists of symptoms or steps
- Bold key terms using **term**
- End with a professional consultation reminder when appropriate`;

export default function App() {
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content: "Hello! I'm **MedGuide**, your AI health assistant powered by RAG (Retrieval-Augmented Generation). I provide evidence-based health information on symptoms, nutrition, exercise, mental health, medications, and more.\n\n⚠️ *I am not a substitute for professional medical advice. Always consult a healthcare provider for diagnosis and treatment.*\n\nHow can I help you today?",
      docs: []
    }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [topK, setTopK] = useState(3);
  const [temperature, setTemperature] = useState(0.3);
  const [showSettings, setShowSettings] = useState(false);
  const [showDocs, setShowDocs] = useState({});
  const bottomRef = useRef(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  async function sendMessage() {
    if (!input.trim() || loading) return;
    const userMsg = { role: "user", content: input };
    const retrieved = retrieveDocs(input, topK);
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    const contextText = retrieved.length
      ? retrieved.map((d, i) =>
          `[Document ${i + 1} | Category: ${d.category} | Relevance: ${(d.score * 100).toFixed(0)}%]\nQ: ${d.question}\nA: ${d.answer}`
        ).join("\n\n")
      : "No closely matching documents found in the health knowledge base for this query.";

    const ragPrompt = `RETRIEVED CONTEXT DOCUMENTS:\n${contextText}\n\nUSER QUESTION: ${input}\n\nUsing the context above, provide a helpful, accurate health response. If the context is insufficient, acknowledge this and recommend consulting a healthcare professional.`;

    const history = messages.map(m => ({ role: m.role, content: m.content }));

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: SYSTEM_PROMPT,
          messages: [
            ...history,
            { role: "user", content: ragPrompt }
          ],
          temperature
        })
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text || "I encountered an error. Please try again.";
      setMessages(prev => [...prev, { role: "assistant", content: reply, docs: retrieved }]);
    } catch (e) {
      setMessages(prev => [...prev, {
        role: "assistant",
        content: "I'm having trouble connecting. Please check your connection and try again.",
        docs: []
      }]);
    }
    setLoading(false);
  }

  function formatText(text) {
    return text
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/\n/g, '<br/>');
  }

  const categoryColors = {
    "Symptoms": "#e53e3e", "Nutrition": "#38a169", "Exercise": "#3182ce",
    "Sleep": "#805ad5", "Mental Health": "#d69e2e", "Chronic Disease": "#c05621",
    "First Aid": "#e53e3e", "Medications": "#2b6cb0", "Prevention": "#276749",
    "Digestive Health": "#744210", "Hydration": "#2c7a7b", "Emergency": "#9b2c2c",
    "Skin Health": "#b7791f", "Eye Health": "#553c9a", "Respiratory": "#2a69ac"
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", background: "#f7f8fc", fontFamily: "'Segoe UI', system-ui, sans-serif" }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg, #1a365d 0%, #2a69ac 100%)", color: "white", padding: "14px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", boxShadow: "0 2px 8px rgba(0,0,0,0.15)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 40, height: 40, borderRadius: "50%", background: "rgba(255,255,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>🏥</div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 18, letterSpacing: "-0.3px" }}>MedGuide AI</div>
            <div style={{ fontSize: 12, opacity: 0.8 }}>RAG-Powered Health Assistant</div>
          </div>
        </div>
        <button onClick={() => setShowSettings(s => !s)} style={{ background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.3)", color: "white", padding: "7px 14px", borderRadius: 8, cursor: "pointer", fontSize: 13, display: "flex", alignItems: "center", gap: 6 }}>
          ⚙️ Settings
        </button>
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <div style={{ background: "white", borderBottom: "1px solid #e2e8f0", padding: "16px 24px", display: "flex", gap: 32, flexWrap: "wrap", alignItems: "center" }}>
          <div>
            <label style={{ fontSize: 13, color: "#4a5568", fontWeight: 600, display: "block", marginBottom: 6 }}>Retrieved Docs (K): <span style={{ color: "#2a69ac" }}>{topK}</span></label>
            <input type="range" min={1} max={5} value={topK} onChange={e => setTopK(+e.target.value)} style={{ width: 160 }} />
            <div style={{ fontSize: 11, color: "#718096", marginTop: 3 }}>Higher K = more context, broader answers</div>
          </div>
          <div>
            <label style={{ fontSize: 13, color: "#4a5568", fontWeight: 600, display: "block", marginBottom: 6 }}>Temperature: <span style={{ color: "#2a69ac" }}>{temperature}</span></label>
            <input type="range" min={0} max={1} step={0.1} value={temperature} onChange={e => setTemperature(+e.target.value)} style={{ width: 160 }} />
            <div style={{ fontSize: 11, color: "#718096", marginTop: 3 }}>Lower = precise, Higher = creative</div>
          </div>
          <div style={{ background: "#ebf8ff", padding: "10px 14px", borderRadius: 8, border: "1px solid #bee3f8" }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: "#2b6cb0" }}>Current Config</div>
            <div style={{ fontSize: 12, color: "#4a5568", marginTop: 4 }}>Model: claude-sonnet-4-20250514</div>
            <div style={{ fontSize: 12, color: "#4a5568" }}>KB: {HEALTH_KNOWLEDGE_BASE.length} documents · Embeddings: TF-IDF + Cosine</div>
          </div>
        </div>
      )}

      {/* Messages */}
      <div style={{ flex: 1, overflowY: "auto", padding: "20px", display: "flex", flexDirection: "column", gap: 16 }}>
        {/* Quick Prompts */}
        {messages.length === 1 && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 8 }}>
            {["What are signs of diabetes?", "How do I manage anxiety?", "How much sleep do I need?", "Signs of a heart attack?", "Best diet for health?"].map(q => (
              <button key={q} onClick={() => { setInput(q); }} style={{ background: "white", border: "1px solid #cbd5e0", borderRadius: 20, padding: "7px 14px", fontSize: 13, color: "#4a5568", cursor: "pointer", transition: "all 0.15s" }}
                onMouseEnter={e => { e.target.style.background = "#ebf8ff"; e.target.style.borderColor = "#90cdf4"; }}
                onMouseLeave={e => { e.target.style.background = "white"; e.target.style.borderColor = "#cbd5e0"; }}
              >{q}</button>
            ))}
          </div>
        )}

        {messages.map((msg, idx) => (
          <div key={idx} style={{ display: "flex", flexDirection: "column", alignItems: msg.role === "user" ? "flex-end" : "flex-start", gap: 6 }}>
            <div style={{
              maxWidth: "80%", padding: "12px 16px",
              background: msg.role === "user" ? "linear-gradient(135deg, #1a365d, #2a69ac)" : "white",
              color: msg.role === "user" ? "white" : "#2d3748",
              borderRadius: msg.role === "user" ? "18px 18px 4px 18px" : "18px 18px 18px 4px",
              boxShadow: "0 1px 4px rgba(0,0,0,0.08)",
              fontSize: 14, lineHeight: 1.6,
              border: msg.role === "assistant" ? "1px solid #e2e8f0" : "none"
            }} dangerouslySetInnerHTML={{ __html: formatText(msg.content) }} />

            {/* Retrieved docs toggle */}
            {msg.role === "assistant" && msg.docs?.length > 0 && (
              <div style={{ maxWidth: "80%" }}>
                <button onClick={() => setShowDocs(s => ({ ...s, [idx]: !s[idx] }))} style={{ background: "none", border: "none", fontSize: 12, color: "#718096", cursor: "pointer", padding: "2px 0", display: "flex", alignItems: "center", gap: 4 }}>
                  📚 {showDocs[idx] ? "Hide" : "Show"} {msg.docs.length} retrieved document{msg.docs.length > 1 ? "s" : ""}
                </button>
                {showDocs[idx] && (
                  <div style={{ display: "flex", flexDirection: "column", gap: 6, marginTop: 6 }}>
                    {msg.docs.map((doc, di) => (
                      <div key={di} style={{ background: "#f7fafc", border: "1px solid #e2e8f0", borderRadius: 8, padding: "8px 12px", fontSize: 12 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                          <span style={{ fontWeight: 600, color: categoryColors[doc.category] || "#4a5568" }}>📁 {doc.category}</span>
                          <span style={{ color: "#a0aec0" }}>Match: {(doc.score * 100).toFixed(0)}%</span>
                        </div>
                        <div style={{ color: "#4a5568" }}>{doc.question}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
            <div style={{ background: "white", border: "1px solid #e2e8f0", borderRadius: "18px 18px 18px 4px", padding: "12px 16px", display: "flex", gap: 6, alignItems: "center" }}>
              {[0, 0.2, 0.4].map((d, i) => (
                <div key={i} style={{ width: 8, height: 8, borderRadius: "50%", background: "#2a69ac", animation: "pulse 1s ease-in-out infinite", animationDelay: `${d}s` }} />
              ))}
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div style={{ background: "white", borderTop: "1px solid #e2e8f0", padding: "12px 20px", display: "flex", gap: 10, alignItems: "flex-end" }}>
        <textarea
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
          placeholder="Ask about symptoms, nutrition, medications, mental health..."
          rows={1}
          style={{ flex: 1, padding: "10px 14px", border: "1.5px solid #cbd5e0", borderRadius: 12, fontSize: 14, resize: "none", outline: "none", fontFamily: "inherit", lineHeight: 1.5, transition: "border-color 0.2s" }}
          onFocus={e => e.target.style.borderColor = "#2a69ac"}
          onBlur={e => e.target.style.borderColor = "#cbd5e0"}
        />
        <button onClick={sendMessage} disabled={loading || !input.trim()} style={{ background: loading || !input.trim() ? "#a0aec0" : "linear-gradient(135deg, #1a365d, #2a69ac)", color: "white", border: "none", borderRadius: 12, padding: "10px 20px", fontSize: 14, fontWeight: 600, cursor: loading || !input.trim() ? "not-allowed" : "pointer", whiteSpace: "nowrap", transition: "all 0.2s" }}>
          {loading ? "..." : "Send →"}
        </button>
      </div>

      <style>{`
        @keyframes pulse { 0%, 100% { opacity: 0.3; transform: scale(0.8); } 50% { opacity: 1; transform: scale(1.2); } }
        textarea::-webkit-scrollbar { width: 4px; } textarea::-webkit-scrollbar-thumb { background: #cbd5e0; border-radius: 2px; }
        ::-webkit-scrollbar { width: 6px; } ::-webkit-scrollbar-thumb { background: #cbd5e0; border-radius: 3px; }
        * { box-sizing: border-box; }
      `}</style>
    </div>
  );
}
